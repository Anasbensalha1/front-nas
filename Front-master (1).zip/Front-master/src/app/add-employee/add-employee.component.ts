import { Component, OnInit } from '@angular/core';
import { Employee } from 'src/app/model/employee/employee.module';
import { EmployeeService } from 'src/app/service/employee.service';
import { Router } from '@angular/router';
import { FormGroup , FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {

  employee: Employee = new Employee();
  public Employeefrom: FormGroup;


  constructor(private employeeService : EmployeeService,
    private router : Router,
    private formBuilder: FormBuilder,
    ) {   this.Employeefrom= this.formBuilder.group({
      sn: ['', Validators.required],
      cn: ['', Validators.required],
      snLangAr: ['', Validators.required],
      cnLangAr: ['', Validators.required],
      CIN: ['', Validators.required],
      govCnrps: ['', Validators.required],
      numtel: ['', Validators.required],
      adresse: ['', Validators.required],
  });}

  ngOnInit(): void {
  }

  createEmployeefrom() {

    }
  saveEmployee(){
    this.employeeService.addEmployee(this.employee).subscribe(data=>{
      console.log(data);
     this.goToEmployeeList();},
     error=> {console.log(error);
      this.goToEmployeeList();});
  }

  goToEmployeeList(){
    this.router.navigate(['/listemp']);
  }

  onSubmit(){
      console.log(this.employee);
      this.saveEmployee();
    }
}
