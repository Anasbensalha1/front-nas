export class Employee {
  id : string;
  uid : string;
  sn : string='';
  cn : string='';
  snLangAr : string='';
  cnLangAr : string='';
  snLangFr : string='';
  cnLangFr : string='';
  givenName : string;
  numtel: string='';
  govCIN : string='';
  govCNRPS : string='';
  password : string='';
  email : string='';
  memberOf : String [];

 constructor(){

 } 

}
