import { Employee } from 'src/app/model/employee/employee.module';

describe('Employee', () => {
  it('should create an instance', () => {
    expect(new Employee()).toBeTruthy();
  });
});
