import { Employee } from 'src/app/model/employee/employee.module';
export class Group {
  id : string;
  uid : string;
  cn : string='';
  cnLangAr : string='';
  cnLangFr : string='';
  descriptionLangAr: string='';
  descriptionLangFr: string='';
  list : Employee [];
  memberOf : String [];

 constructor(){

 } 

}
