import { Employee } from 'src/app/model/employee/employee.module';
export class Structure {
  id : string;
  uid : string;
  cn : string='';
  cnLangAr : string='';
  cnLangFr : string='';
  descriptionLangAr: string='';
  descriptionLangFr: string='';
  address : string='';
  contact : string='';
  list : Employee [];
  memberOf : String [];

 constructor(){

 } 

}
