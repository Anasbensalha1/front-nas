import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { Structure } from 'src/app/model/structure/structure.module';
import { StructureService } from 'src/app/service/structure.service';

@Component({
  selector: 'app-list-structures',
  templateUrl: './list-structures.component.html',
  styleUrls: ['./list-structures.component.css']
})
export class ListStructuresComponent implements OnInit {

  structures : Structure [] = [];
  

  constructor(private structureService : StructureService) { }

  ngOnInit(): void {
    
   this.getStructures();
  }
  

  public getStructures() {
   /* this.structureService.getAllStructure().subscribe(data=>{
      this.structures=data;
    }); */
    const structure = new Structure();
    structure.cn = "shili";
    structure.contact ="ilef";
    structure.uid = "2556";

    this.structures.push(structure);
  }
  
  public deleteStructureByUid(structure_uid:string){
    this.structureService.deleteStructureByUid(structure_uid).subscribe(data=>{
      alert("Structure supprimée avec succès");
    },
    error=>{
      alert("Structure n'est pas supprimée");
    }
    );
    
  }

}
