import { Component, OnInit } from '@angular/core';
import { Group } from 'src/app/model/group/group.module';
import { GroupService } from 'src/app/service/group.service';
import { Router } from '@angular/router';
import { ActivatedRoute} from '@angular/router';

@Component({
  selector: 'app-update-group',
  templateUrl: './update-group.component.html',
  styleUrls: ['./update-group.component.css']
})
export class UpdateGroupComponent implements OnInit {

  group: Group = new Group();
  group_uid: any;

  constructor(private groupService : GroupService,
    private router : Router,
    private activatedroute: ActivatedRoute) { 
      this.activatedroute.paramMap.subscribe(params => {
        this.group_uid = params.get('uid');
        console.log(this.group_uid);
        this.getGroupByUid(this.group_uid);
    });
     }

  ngOnInit(): void {
  }

  getGroupByUid(uid:number) {
    this.groupService.getGroupByUid(uid).subscribe(
        data => {
            this.group = data;
        },
        error => console.log(error)
    );

}

  saveGroup(){
    this.groupService.addGroup(this.group).subscribe(data=>{
      console.log(data);
     this.goToGroupList();},
     error=> console.log(error));
  }

  goToGroupList(){
    this.router.navigate(['/listgroup']);
  }

  onSubmit(){
      console.log(this.group);
      this.saveGroup();
    }
}


