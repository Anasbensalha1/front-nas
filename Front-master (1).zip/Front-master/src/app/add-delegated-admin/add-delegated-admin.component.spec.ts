import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddDelegatedAdminComponent } from './add-delegated-admin.component';

describe('AddDelegatedAdminComponent', () => {
  let component: AddDelegatedAdminComponent;
  let fixture: ComponentFixture<AddDelegatedAdminComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddDelegatedAdminComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddDelegatedAdminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
