import { Component, OnInit } from '@angular/core';
import { DelegatedAdmin } from 'src/app/model/delegated-admin/delegated-admin.module';
import { DelegatedAdminService } from 'src/app/service/delegated-admin.service';
import { Router } from '@angular/router'
import { FormGroup , FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-add-delegated-admin',
  templateUrl: './add-delegated-admin.component.html',
  styleUrls: ['./add-delegated-admin.component.css']
})
export class AddDelegatedAdminComponent implements OnInit {

  admin: DelegatedAdmin = new DelegatedAdmin();
  public DelegatedAdminfrom: FormGroup;


  constructor(private adminService : DelegatedAdminService,
    private router : Router,
    private formBuilder: FormBuilder,
    ) {   this.DelegatedAdminfrom= this.formBuilder.group({
      sn: ['', Validators.required],
      cn: ['', Validators.required],
      snLangAr: ['', Validators.required],
      cnLangAr: ['', Validators.required],
      CIN: ['', Validators.required],
      govCnrps: ['', Validators.required],
      numtel: ['', Validators.required],
      adresse: ['', Validators.required],
  });}

  ngOnInit(): void {
  }
  
  createDelegatedAdminfrom() {
      
    }
  saveDelegatedAdmin(){
    this.adminService.addDelegatedAdmin(this.admin).subscribe(data=>{
      console.log(data);
     this.goToDelegatedAdminList();},
     error=> {console.log(error);
      this.goToDelegatedAdminList();});
  }

  goToDelegatedAdminList(){
    this.router.navigate(['/listeadmin']);
  }

  onSubmit(){
      console.log(this.admin);
      this.saveDelegatedAdmin();
    }

}
