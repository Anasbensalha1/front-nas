import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { Employee } from 'src/app/model/employee/employee.module';
import { EmployeeService } from 'src/app/service/employee.service';

@Component({
  selector: 'app-list-employees',
  templateUrl: './list-employees.component.html',
  styleUrls: ['./list-employees.component.css']
})
export class ListEmployeesComponent implements OnInit {


  employees : Employee [] = [];


  constructor(private employeeService : EmployeeService) { }

  ngOnInit(): void {

   this.getEmployees();
  }


  public getEmployees() {
   this.employeeService.getAllEmployee().subscribe(data=>{
      this.employees=data;
    });
/*     const employee = new Employee();
    employee.sn = "shili";
    employee.cn ="ilef";
    employee.uid = "2556";

    this.employees.push(employee); */
  }

  public deleteEmployeeByUid(employee_uid:string){
    this.employeeService.deleteEmployeeByUid(employee_uid).subscribe(data=>{
    this.getEmployees();
      alert("Employé supprimé avec succès");
    },
    error=>{
      alert("Employé n'est pas supprimé");
    }
    );

  }
}
