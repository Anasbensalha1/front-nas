import { Component, OnInit } from '@angular/core';
import { Employee } from 'src/app/model/employee/employee.module';
import { EmployeeService } from 'src/app/service/employee.service';
import { Router } from '@angular/router';
<<<<<<< HEAD
import { ActivatedRoute} from '@angular/router';
=======
import {ActivatedRoute} from '@angular/router';
import { FormGroup , FormBuilder, Validators } from '@angular/forms';
>>>>>>> 27c8ac661800f1837b0f484f37f483b337071b65

@Component({
  selector: 'app-update-employee',
  templateUrl: './update-employee.component.html',
  styleUrls: ['./update-employee.component.css']
})
export class UpdateEmployeeComponent implements OnInit {

  employee: Employee = new Employee();
  employee_uid: any;
    public Employeefrom: FormGroup;

  constructor(private employeeService : EmployeeService,
    private router : Router,
    private formBuilder: FormBuilder,
    private activatedroute: ActivatedRoute) {
    this.Employeefrom= this.formBuilder.group({
          sn: ['', Validators.required],
          cn: ['', Validators.required],
          snLangAr: ['', Validators.required],
          cnLangAr: ['', Validators.required],
          CIN: ['', Validators.required],
          govCnrps: ['', Validators.required],
          numtel: ['', Validators.required],
          adresse: ['', Validators.required],
      });
      this.activatedroute.paramMap.subscribe(params => {
        this.employee_uid = params.get('uid');
        console.log(this.employee_uid);
        this.getEmployeeByUid(this.employee_uid);
    });
     }

  ngOnInit(): void {
  }

  getEmployeeByUid(uid:number) {
    this.employeeService.getEmployeeByUid(uid).subscribe(
        data => {
            this.employee = data;
        },
        error => console.log(error)
    );

}

  saveEmployee(){
    this.employeeService.updateEmployee(this.employee).subscribe(data=>{
      console.log(data);
     this.goToEmployeeList();},
     error=> console.log(error));
  }

  goToEmployeeList(){
    this.router.navigate(['/listeemp']);
  }

  onSubmit(){
      console.log(this.employee);
      this.saveEmployee();
    }
}
