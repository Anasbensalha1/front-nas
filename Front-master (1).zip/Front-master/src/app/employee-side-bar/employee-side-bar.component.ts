import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee-side-bar',
  templateUrl: './employee-side-bar.component.html',
  styleUrls: ['./employee-side-bar.component.css']
})
export class EmployeeSideBarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
