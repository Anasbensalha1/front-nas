import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { EditComponent } from './edit/edit.component';
import { ListEmployeesComponent } from './list-employees/list-employees.component';
import { ListStructuresComponent } from './list-structures/list-structures.component';
import { ListGroupsComponent } from './list-groups/list-groups.component';
import { ListDelegatedAdminComponent } from './list-delegated-admin/list-delegated-admin.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { UpdateEmployeeComponent } from './update-employee/update-employee.component';
import { AddGroupComponent } from './add-group/add-group.component';
import { AddDelegatedAdminComponent } from './add-delegated-admin/add-delegated-admin.component';
import { AddStructureComponent } from './add-structure/add-structure.component';
import { UpdateStructureComponent } from './update-structure/update-structure.component';
import { UpdateGroupComponent } from './update-group/update-group.component';
import { UpdateDelegatedAdminComponent } from './update-delegated-admin/update-delegated-admin.component';


const routes: Routes = [
  {path :'login' , component : LoginComponent},
  {path :'sidebar' , component : SidebarComponent},
  {path :'edit' , component : EditComponent},
  {path :'listemp' , component : ListEmployeesComponent},
  {path :'liststructures' , component : ListStructuresComponent},
  {path :'listgroups' , component : ListGroupsComponent},
  {path :'listadmin' , component : ListDelegatedAdminComponent},
  {path : 'dashboard', component : DashboardComponent},
  {path :'addemployee' , component : AddEmployeeComponent},
  {path :'updateemployee/:uid' , component : UpdateEmployeeComponent},
  {path :'addgroup' , component : AddGroupComponent},
  {path :'addstructure' , component : AddStructureComponent},
  {path :'addadmin' , component : AddDelegatedAdminComponent},
  {path :'updatestructure/:uid' , component : UpdateStructureComponent},
  {path :'updategroup/:uid' , component : UpdateGroupComponent},
  {path :'updateadmin/:uid' , component : UpdateDelegatedAdminComponent},
  {path :'' , redirectTo : 'login' , pathMatch:'full'},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
