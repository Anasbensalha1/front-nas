import { Component, OnInit } from '@angular/core';
import { Group } from 'src/app/model/group/group.module';
import { GroupService } from 'src/app/service/group.service';
import { Router } from '@angular/router'
import { FormGroup , FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-add-group',
  templateUrl: './add-group.component.html',
  styleUrls: ['./add-group.component.css']
})
export class AddGroupComponent implements OnInit {
 
  group: Group = new Group();
  public Groupfrom: FormGroup;


  constructor(private groupService : GroupService,
    private router : Router,
    private formBuilder: FormBuilder,
    ) {   this.Groupfrom= this.formBuilder.group({
      cn: ['', Validators.required],
      cnLangAr: ['', Validators.required],
      descriptionLangAr: ['', Validators.required],
      descritpionLangAr: ['', Validators.required],
  });}

  ngOnInit(): void {
  }
  
  createGroup() {
      
    }
  saveGroup(){
    this.groupService.addGroup(this.group).subscribe(data=>{
      console.log(data);
     this.goToGroupList();},
     error=> {console.log(error);
      this.goToGroupList();});
  }

  goToGroupList(){
    this.router.navigate(['/listegroup']);
  }

  onSubmit(){
      console.log(this.group);
      this.saveGroup();
    }


}
