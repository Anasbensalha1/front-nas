import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Observable } from 'rxjs';
import { DelegatedAdmin } from 'src/app/model/delegated-admin/delegated-admin.module';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class DelegatedAdminService {
  private URL = "http://localhost:8080/";
 

  constructor(private httpClient : HttpClient) {
   
  }

   getAllDelegatedAdmin ():Observable<DelegatedAdmin[]>{
      return this.httpClient.get<DelegatedAdmin[]>('$(this.URL}'+'find-all-delegatedadmin');
    }

   addDelegatedAdmin (delegatedadmin:DelegatedAdmin):Observable<object>{
    return this.httpClient.post('$(this.URL)'+'add-delegatedadmin', delegatedadmin);
  }

  getDelegatedAdminByUid(delegatedadmin_uid: any): Observable<DelegatedAdmin> {
    return this.httpClient.get<DelegatedAdmin>(this.URL + 'find-delegatedadmin-by-uid/' + delegatedadmin_uid);
}
  updateDelegatedAdmin (delegatedadmin:DelegatedAdmin):Observable<object>{
    return this.httpClient.put('$(this.URL)'+'update-delegatedadmin', delegatedadmin);
  }

  deleteDelegatedAdminByUid(delegatedadmin_uid: any): Observable<void> {
    return this.httpClient.delete<void>(this.URL + 'delete-delegatedadmin-by-uid/' + delegatedadmin_uid);
}

}
