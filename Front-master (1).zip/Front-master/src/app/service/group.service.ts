import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Group } from 'src/app/model/group/group.module';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class GroupService {
   
  private URL = "http://localhost:8080/";
 

  constructor(private httpClient : HttpClient) {
   
  }

   getAllGroup ():Observable<Group[]>{
      return this.httpClient.get<Group[]>('$(this.URL}'+'find-all-group');
    }

   addGroup (group:Group):Observable<object>{
    return this.httpClient.post('$(this.URL)'+'add-group', group);
  }

  getGroupByUid(group_uid: any): Observable<Group> {
    return this.httpClient.get<Group>(this.URL + 'find-all-group-by-uid/' + group_uid);
}
  updateGroup (group:Group):Observable<object>{
    return this.httpClient.put('$(this.URL)'+'update-group', group);
  }

  deleteGroupByUid(group_uid: any): Observable<void> {
    return this.httpClient.delete<void>(this.URL + 'delete-group-by-uid/' + group_uid);
}

}
