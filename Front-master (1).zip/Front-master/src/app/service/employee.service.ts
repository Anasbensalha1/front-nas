import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Employee } from 'src/app/model/employee/employee.module';
import { environment } from 'src/environments/environment';
@Injectable({
  providedIn: 'root'
})
export class EmployeeService {


    private URL = "http://localhost:8080/user/";


  constructor(private httpClient : HttpClient) {

  }

   getAllEmployee ():Observable<Employee[]>{
      return this.httpClient.get<Employee[]>(this.URL+'find-all-user');
    }

   addEmployee (employee:Employee):Observable<object>{
    return this.httpClient.post(this.URL+'add-user', employee);
  }

  getEmployeeByUid(employee_uid: any): Observable<Employee> {
    return this.httpClient.get<Employee>(this.URL + 'find-user-by-uid/' + employee_uid);
}
  updateEmployee (employee:Employee):Observable<object>{
    return this.httpClient.put(this.URL+'update-user', employee);
  }

  deleteEmployeeByUid(employee_uid: any): Observable<void> {
    return this.httpClient.delete<void>(this.URL + 'delete-user/' + employee_uid);
}

}
