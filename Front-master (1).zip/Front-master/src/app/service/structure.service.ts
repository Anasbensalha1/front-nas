import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Structure } from 'src/app/model/structure/structure.module';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class StructureService {



    
  private URL = "http://localhost:8080/";
 

  constructor(private httpClient : HttpClient) {
   
  }

   getAllStructure ():Observable<Structure[]>{
      return this.httpClient.get<Structure[]>('$(this.URL}'+'find-all-structure');
    }

   addStructure (structure:Structure):Observable<object>{
    return this.httpClient.post('$(this.URL)'+'add-structure', structure);
  }

  getStructureByUid(structure_uid: any): Observable<Structure> {
    return this.httpClient.get<Structure>(this.URL + 'find-structure-by-uid/' + structure_uid);
}
  updateStructure (structure:Structure):Observable<object>{
    return this.httpClient.put('$(this.URL)'+'update-structure', structure);
  }

  deleteStructureByUid(structure_uid: any): Observable<void> {
    return this.httpClient.delete<void>(this.URL + 'delete-structure-by-uid/' + structure_uid);
}

}
