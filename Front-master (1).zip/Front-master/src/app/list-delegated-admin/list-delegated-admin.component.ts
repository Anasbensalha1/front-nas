import { Component, OnInit } from '@angular/core';
import { DelegatedAdmin } from 'src/app/model/delegated-admin/delegated-admin.module';
import { DelegatedAdminService } from 'src/app/service/delegated-admin.service';

@Component({
  selector: 'app-list-delegated-admin',
  templateUrl: './list-delegated-admin.component.html',
  styleUrls: ['./list-delegated-admin.component.css']
})
export class ListDelegatedAdminComponent implements OnInit {
  admins : DelegatedAdmin [] = [];
  

  constructor(private delegatedadminService : DelegatedAdminService) { }

  ngOnInit(): void {
    
   this.getDelegatedAdmins();
  }
  

  public getDelegatedAdmins() {
   /* this.delegatedadminService.getAllDelegatedAdmin().subscribe(data=>{
      this.groups=data;
    }); */
    const delegatedadmin = new DelegatedAdmin();
    delegatedadmin.cn ="ilef";
    delegatedadmin.uid = "2556";

    this.admins.push(delegatedadmin);
  }
  
  public deleteDelegatedAdminByUid(delegatedadmin_uid:string){
    this.delegatedadminService.deleteDelegatedAdminByUid(delegatedadmin_uid).subscribe(data=>{
      alert("Admin délégué supprimé avec succès");
    },
    error=>{
      alert("Admin délégué n'est pas supprimé");
    }
    );
    
  }
}
