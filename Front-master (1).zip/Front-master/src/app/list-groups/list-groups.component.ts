import { Component, OnInit } from '@angular/core';
import { Group } from 'src/app/model/group/group.module';
import { GroupService } from 'src/app/service/group.service';

@Component({
  selector: 'app-list-groups',
  templateUrl: './list-groups.component.html',
  styleUrls: ['./list-groups.component.css']
})
export class ListGroupsComponent implements OnInit {

  groups : Group [] = [];
  

  constructor(private groupService : GroupService) { }

  ngOnInit(): void {
    
   this.getGroups();
  }
  

  public getGroups() {
   /* this.groupService.getAllGroup().subscribe(data=>{
      this.groups=data;
    }); */
    const group = new Group();
    group.cn ="ilef";
    group.uid = "2556";

    this.groups.push(group);
  }
  
  public deleteGroupByUid(group_uid:string){
    this.groupService.deleteGroupByUid(group_uid).subscribe(data=>{
      alert("Groupe supprimé avec succès");
    },
    error=>{
      alert("Groupe n'est pas supprimé");
    }
    );
    
  }
}
