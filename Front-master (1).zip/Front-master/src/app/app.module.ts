import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { EditComponent } from './edit/edit.component';
import { ListEmployeesComponent } from './list-employees/list-employees.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ListDelegatedAdminComponent } from './list-delegated-admin/list-delegated-admin.component';
import { ListStructuresComponent } from './list-structures/list-structures.component';
import { ListGroupsComponent } from './list-groups/list-groups.component';
import { EmployeeSideBarComponent } from './employee-side-bar/employee-side-bar.component';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { UpdateEmployeeComponent } from './update-employee/update-employee.component';
import { AddStructureComponent } from './add-structure/add-structure.component';
import { AddGroupComponent } from './add-group/add-group.component';
import { AddDelegatedAdminComponent } from './add-delegated-admin/add-delegated-admin.component';
import { UpdateStructureComponent } from './update-structure/update-structure.component';
import { UpdateGroupComponent } from './update-group/update-group.component';
import { UpdateDelegatedAdminComponent } from './update-delegated-admin/update-delegated-admin.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    SidebarComponent,
    EditComponent,
    ListEmployeesComponent,
    DashboardComponent,
    ListDelegatedAdminComponent,
    ListStructuresComponent,
    ListGroupsComponent,
    EmployeeSideBarComponent,
    AddEmployeeComponent,
    UpdateEmployeeComponent,
    AddStructureComponent,
    AddGroupComponent,
    AddDelegatedAdminComponent,
    UpdateStructureComponent,
    UpdateGroupComponent,
    UpdateDelegatedAdminComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule 
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
