import { Component, OnInit } from '@angular/core';
import { Structure } from 'src/app/model/structure/structure.module';
import { StructureService } from 'src/app/service/structure.service';
import { Router } from '@angular/router'
import { FormGroup , FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-add-structure',
  templateUrl: './add-structure.component.html',
  styleUrls: ['./add-structure.component.css']
})
export class AddStructureComponent implements OnInit {

  structure: Structure = new Structure();
  public Structurefrom: FormGroup;


  constructor(private structureService : StructureService,
    private router : Router,
    private formBuilder: FormBuilder,
    ) {   this.Structurefrom= this.formBuilder.group({
      cn: ['', Validators.required],
      cnLangAr: ['', Validators.required],
      descriptionLangAr: ['', Validators.required],
      descritpionLangAr: ['', Validators.required],
      contact: ['', Validators.required],
      address: ['', Validators.required],
  });}

  ngOnInit(): void {
  }
  
  createStructure() {
      
    }
  saveStructure(){
    this.structureService.addStructure(this.structure).subscribe(data=>{
      console.log(data);
     this.goToStructureList();},
     error=> {console.log(error);
      this.goToStructureList();});
  }

  goToStructureList(){
    this.router.navigate(['/listestructure']);
  }

  onSubmit(){
      console.log(this.structure);
      this.saveStructure();
    }

}
