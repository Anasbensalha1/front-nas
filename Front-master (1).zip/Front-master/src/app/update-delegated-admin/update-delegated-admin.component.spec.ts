import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateDelegatedAdminComponent } from './update-delegated-admin.component';

describe('UpdateDelegatedAdminComponent', () => {
  let component: UpdateDelegatedAdminComponent;
  let fixture: ComponentFixture<UpdateDelegatedAdminComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateDelegatedAdminComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateDelegatedAdminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
