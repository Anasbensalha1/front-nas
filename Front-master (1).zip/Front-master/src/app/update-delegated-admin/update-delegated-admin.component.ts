import { Component, OnInit } from '@angular/core';
import { DelegatedAdmin } from 'src/app/model/delegated-admin/delegated-admin.module';
import { DelegatedAdminService } from 'src/app/service/delegated-admin.service';
import { Router } from '@angular/router';
import { ActivatedRoute} from '@angular/router';

@Component({
  selector: 'app-update-delegated-admin',
  templateUrl: './update-delegated-admin.component.html',
  styleUrls: ['./update-delegated-admin.component.css']
})
export class UpdateDelegatedAdminComponent implements OnInit {

  admin: DelegatedAdmin = new DelegatedAdmin();
  delegatedadmin_uid: any;

  constructor(private adminService : DelegatedAdminService,
    private router : Router,
    private activatedroute: ActivatedRoute) { 
      this.activatedroute.paramMap.subscribe(params => {
        this.delegatedadmin_uid = params.get('uid');
        console.log(this.delegatedadmin_uid);
        this.getDelegatedAdminByUid(this.delegatedadmin_uid);
    });
     }

  ngOnInit(): void {
  }

  getDelegatedAdminByUid(uid:number) {
    this.adminService.getDelegatedAdminByUid(uid).subscribe(
        data => {
            this.admin = data;
        },
        error => console.log(error)
    );

}

  saveDelegatedAdmin(){
    this.adminService.addDelegatedAdmin(this.admin).subscribe(data=>{
      console.log(data);
     this.goToDelegatedAdminList();},
     error=> console.log(error));
  }

  goToDelegatedAdminList(){
    this.router.navigate(['/listeadmin']);
  }

  onSubmit(){
      console.log(this.admin);
      this.saveDelegatedAdmin();
    }
}
