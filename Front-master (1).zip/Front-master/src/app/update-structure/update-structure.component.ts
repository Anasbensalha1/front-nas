import { Component, OnInit } from '@angular/core';
import { Structure } from 'src/app/model/structure/structure.module';
import { StructureService } from 'src/app/service/structure.service';
import { Router } from '@angular/router';
import { ActivatedRoute} from '@angular/router';

@Component({
  selector: 'app-update-structure',
  templateUrl: './update-structure.component.html',
  styleUrls: ['./update-structure.component.css']
})
export class UpdateStructureComponent implements OnInit {

  structure: Structure = new Structure();
  structure_uid: any;

  constructor(private structureService : StructureService,
    private router : Router,
    private activatedroute: ActivatedRoute) { 
      this.activatedroute.paramMap.subscribe(params => {
        this.structure_uid = params.get('uid');
        console.log(this.structure_uid);
        this.getStructureByUid(this.structure_uid);
    });
     }

  ngOnInit(): void {
  }

  getStructureByUid(uid:number) {
    this.structureService.getStructureByUid(uid).subscribe(
        data => {
            this.structure = data;
        },
        error => console.log(error)
    );

}

  saveStructure(){
    this.structureService.addStructure(this.structure).subscribe(data=>{
      console.log(data);
     this.goToStructureList();},
     error=> console.log(error));
  }

  goToStructureList(){
    this.router.navigate(['/liststructure']);
  }

  onSubmit(){
      console.log(this.structure);
      this.saveStructure();
    }

}
